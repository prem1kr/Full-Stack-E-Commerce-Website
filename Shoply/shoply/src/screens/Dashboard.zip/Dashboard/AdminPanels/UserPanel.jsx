import React from 'react'
import { Box, Typography } from "@mui/material";
import Title from './Title';

const UserPanel = () => {
  return (
    <Box
      sx={{
        padding: "30px 60px",
      }}
    >
      <Title heading={"Users"}/>

      {/* <Box mt={2} bgcolor={"whitesmoke"}>
        {products &&
          products.map((product) => (
            <Box
              display={"flex"}
              alignItems={"center"}
              justifyContent={"space-between"}
              height={"150px"}
              overflow={"hidden"}
              borderBottom={"1px solid #e2e2e2"}
              marginBottom={1}
            >
              <Box  display={"flex"} height={"100%"} width={"65%"} alignItems={"center"} overflow={"hidden"} py={2.2}>
                <Box width={"180px"} px={"20px"} alignSelf={"flex-start"}>
                  <img
                    src={product.image}
                    width={"140px"}
                    height={"100px"}
                    style={{ objectFit: "contain", objectPosition: "top" }}
                    alt={product.name}
                  />
                </Box>
                <Box
                  display={"flex"}
                  flexDirection={"column"}
                  justifyItems={"flex-start"}
                  height={"100%"}
                //   py={2}
                  gap={1}
                >
                  <Typography
                    variant="h3"
                    sx={{
                      fontSize: "13px",
                      fontWeight: "500",
                      fontFamily: "'Jost', sans-serif",
                      lineHeight: "1.11",
                      wordWrap: "break-word",
                      color: "#A0A0A0",
                    }}
                  >
                    Category : {product.category}
                  </Typography>
                  <Typography
                    variant="h2"
                    sx={{
                      fontSize: "18px",
                      fontWeight: "500",
                      fontFamily: "'Jost', sans-serif",
                      lineHeight: "1.33",
                      wordWrap: "break-word",
                      color: "#4B3049",
                    }}
                  >
                    {product.name}
                  </Typography>
                  <Box display={"flex"}>
                    <Typography
                      variant="h3"
                      sx={{
                        fontSize: "13px",
                        fontWeight: "500",
                        fontFamily: "'Jost', sans-serif",
                        lineHeight: "1.11",
                        wordWrap: "break-word",
                        color: "#000000",
                      }}
                    >
                      Price : Rs. {product.price} | Count In Stock :{" "}
                      {product.countInStock}
                    </Typography>
                  </Box>
                </Box>
              </Box>
              <Box py={2.2} height={"100%"} px={3} width={"35%"} textAlign={"right"} display={"flex"} flexDirection={"column"} gap={2} alignItems={"flex-end"}>
                <Button style={{width : "30%"}}>Delete</Button>
                <Button style={{width : "30%"}}>Update</Button>
              </Box>
            </Box>
          ))}
      </Box> */}
    </Box>
  )
}

export default UserPanel
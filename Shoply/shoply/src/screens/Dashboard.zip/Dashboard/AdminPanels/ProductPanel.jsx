import React, { useState } from "react";
import {
  Box,
  Pagination,
  Typography,
  Modal,
  Button as MuiButton,
  TextField,
} from "@mui/material";
import { useSelector, useDispatch } from "react-redux";

import { paginate } from "../../../utils/utils";
import Title from "./Title";

import ProductPanelItem from "../../../components/ProductPanelItem";

const ProductPanel = () => {
  
  const { products } = useSelector((state) => state.productstate);

  const [pageSize, setPageSize] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);
  

  const handlePageChange = (e, value) => {
    setCurrentPage(value);
  };

  const paginatedResult = paginate(products, currentPage - 1, pageSize);

  return (
    <Box
      sx={{
        padding: "30px 60px",
      }}
    >
      <Title heading={"Products"} />
      <Box mt={4} bgcolor={"whitesmoke"}>
        {products &&
          paginatedResult &&
          paginatedResult.map((product) => (
            <ProductPanelItem  key={product._id} product={product} />
          ))}
        {products && (
          <Box
            py={3}
            display={"flex"}
            justifyContent={"center"}
            alignItems={"center"}
          >
            <Pagination
              count={Math.ceil(products.length / pageSize)}
              color="primary"
              page={currentPage}
              onChange={handlePageChange}
            />
          </Box>
        )}
      </Box>

      {/* <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          component={"form"}
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "700px",
            bgcolor: "#F4EDF2",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Box display={"flex"} gap={3} mb={2}>
            <TextField
              variant="outlined"
              placeholder="Product Name"
              size="small"
              sx={{
                width: "50%",
              }}
            />
            <TextField
              variant="outlined"
              placeholder="Product Image"
              size="small"
              sx={{
                width: "50%",
              }}
            />
          </Box>
          <Box mb={2}>
            <TextField
              variant="outlined"
              placeholder="Product Description"
              size="small"
              fullWidth
              multiline
              rows={4}
            />
          </Box>
          <Box display={"flex"} gap={3} mb={2}>
            <TextField
              variant="outlined"
              type="number"
              placeholder="Product Price"
              size="small"
              sx={{
                width: "50%",
              }}
            />
            <TextField
              variant="outlined"
              type="number"
              placeholder="Count In Stock"
              size="small"
              sx={{
                width: "50%",
              }}
            />
          </Box>
          <Box display={"flex"} gap={3} mb={2}>
            <TextField
              variant="outlined"
              placeholder="Product Category"
              size="small"
              sx={{
                width: "50%",
              }}
            />
            <TextField
              variant="outlined"
              placeholder="Brand"
              size="small"
              sx={{
                width: "50%",
              }}
            />
          </Box>

          <MuiButton variant="contained">Submit</MuiButton>
        </Box>
      </Modal> */}
    </Box>
  );
};

export default ProductPanel;
